import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.input.ClipboardContent;
import javafx.scene.input.Dragboard;
import javafx.scene.input.TransferMode;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Random;
import java.util.stream.Collectors;

public class OyunUI extends Application {

    private static final int MAX_TUR = 5;
    private static final int BASLANGIC_KART_SAYISI = 6;
    private static final int TURNS_PER_ROUND = 3;

    private final Random random = new Random();

    private Stage stage;
    private Oyuncu oyuncu;
    private Oyuncu bilgisayar;

    private int tur = 1;
    private int gerekenKartSayisi = 3;
    private boolean oyunBitti = false;

    private Label baslikLabel;
    private Label turLabel;
    private Label durumLabel;
    private Label oyuncuSkorLabel;
    private Label bilgisayarSkorLabel;
    private Label oyuncuKartSayisiLabel;
    private Label bilgisayarKartSayisiLabel;
    private Label secimBilgisiLabel;

    private TextArea logArea;
    private TextField isimField;
    private Button savasButton;

    private FlowPane oyuncuKartPane;
    private FlowPane bilgisayarKartPane;
    private VBox secilenKartPane;

    private final List<SavasAraclari> secilenKartlar = new ArrayList<>();

    private Image arkaPlanResmi;
    private Image oyuncuKartResmi;
    private Image bilgisayarKartResmi;

    @Override
    public void start(Stage primaryStage) {
        this.stage = primaryStage;
        buResimleriYukle();
        showAnaMenu();
        stage.setTitle("Savaş Araçları Oyunu - Drag & Drop");
        stage.setMinWidth(1200);
        stage.setMinHeight(800);
        stage.show();
    }

    private void buResimleriYukle() {
        arkaPlanResmi = yukleResim("/png/backGround.png");
        oyuncuKartResmi = yukleResim("/png/oyuncuKartGörünümü.png");
        bilgisayarKartResmi = yukleResim("/png/KartGörünümü.png");
    }

    private Image yukleResim(String path) {
        try {
            return new Image(Objects.requireNonNull(getClass().getResource(path)).toExternalForm());
        } catch (Exception e) {
            return null;
        }
    }

    private void showAnaMenu() {
        VBox root = new VBox(22);
        root.setAlignment(Pos.CENTER);
        root.setPadding(new Insets(40));
        root.setPrefSize(1200, 800);
        applyArkaPlan(root);

        Label title = new Label("⚔ SAVAŞ ARAÇLARI OYUNU ⚔");
        title.setFont(Font.font("Arial", FontWeight.EXTRA_BOLD, 42));
        title.setTextFill(Color.WHITE);

        Label subtitle = new Label("Kartları sürükleyerek seç ve savaşa gir!");
        subtitle.setFont(Font.font("Arial", FontWeight.BOLD, 18));
        subtitle.setTextFill(Color.web("#FFD700"));

        VBox infoBox = new VBox(12);
        infoBox.setPadding(new Insets(20));
        infoBox.setMaxWidth(700);
        infoBox.setStyle(
                "-fx-background-color: rgba(20, 28, 38, 0.85);" +
                "-fx-background-radius: 20;" +
                "-fx-border-color: rgba(255, 215, 0, 0.3);" +
                "-fx-border-radius: 20;" +
                "-fx-border-width: 2;"
        );

        Label infoTitle = new Label("Oyun Rehberi");
        infoTitle.setFont(Font.font("Arial", FontWeight.BOLD, 20));
        infoTitle.setTextFill(Color.web("#FFD700"));

        TextArea infoText = new TextArea(
                "✓ Adını gir ve oyunu başlat\n" +
                "✓ 6 kart ile başlarsın\n" +
                "✓ Her turda 3 kartı sürükleyip seçilen alana bırak\n" +
                "✓ Kartlar karşı taraf ile savaşır\n" +
                "✓ 5 tur sonunda en yüksek skoru alan kazanır!\n\n" +
                "Avantaj Sistemi: Deniz > Hava > Kara > Deniz"
        );
        infoText.setWrapText(true);
        infoText.setEditable(false);
        infoText.setPrefRowCount(7);
        infoText.setStyle(
                "-fx-control-inner-background: rgba(8, 12, 20, 0.9);" +
                "-fx-text-fill: #EAF2FF;" +
                "-fx-font-size: 14;" +
                "-fx-font-family: 'Segoe UI';" +
                "-fx-background-radius: 15;"
        );

        infoBox.getChildren().addAll(infoTitle, infoText);

        HBox inputBox = new HBox(12);
        inputBox.setAlignment(Pos.CENTER);
        inputBox.setMaxWidth(500);

        Label nameLabel = new Label("Adın:");
        nameLabel.setFont(Font.font("Arial", FontWeight.BOLD, 16));
        nameLabel.setTextFill(Color.WHITE);

        isimField = new TextField();
        isimField.setPromptText("Adınızı yazın...");
        isimField.setPrefWidth(250);
        isimField.setStyle(
                "-fx-font-size: 14;" +
                "-fx-padding: 10;" +
                "-fx-background-radius: 10;" +
                "-fx-border-radius: 10;" +
                "-fx-border-color: rgba(255, 215, 0, 0.3);"
        );

        inputBox.getChildren().addAll(nameLabel, isimField);

        Button startButton = new Button("🎮 OYUNU BAŞLAT");
        startButton.setPrefWidth(200);
        startButton.setStyle(buttonStyle("#FFD700", "#1a1a2e"));
        startButton.setFont(Font.font("Arial", FontWeight.BOLD, 14));
        startButton.setOnAction(e -> oyunuBaslat());

        root.getChildren().addAll(title, subtitle, infoBox, inputBox, startButton);

        Scene scene = new Scene(root, 1200, 800);
        stage.setScene(scene);
    }

    private void oyunuBaslat() {
        String isim = isimField.getText() == null ? "" : isimField.getText().trim();
        if (isim.isEmpty()) {
            bilgiKutusu(Alert.AlertType.WARNING, "Uyarı", "Lütfen adınızı girin!");
            return;
        }

        oyuncu = new Oyuncu(1, isim, 0);
        bilgisayar = new Oyuncu(2, "Bilgisayar", 0);
        tur = 1;
        oyunBitti = false;
        secilenKartlar.clear();
        oyuncu.getKartListesi().clear();
        bilgisayar.getKartListesi().clear();
        oyuncu.getSecilenKartlar().clear();
        bilgisayar.getSecilenKartlar().clear();

        for (int i = 0; i < BASLANGIC_KART_SAYISI; i++) {
            oyuncu.KartEkle(baslangicKartiUret());
            bilgisayar.KartEkle(baslangicKartiUret());
        }

        showOyunEkrani();
        turuHazirla();
    }

    private void showOyunEkrani() {
        BorderPane root = new BorderPane();
        root.setPadding(new Insets(16));
        applyArkaPlan(root);

        // Üst panel
        VBox topPanel = new VBox(8);
        topPanel.setPadding(new Insets(12));
        topPanel.setStyle(panelStyle());

        baslikLabel = new Label("SAVAŞ ARAÇLARI OYUNU - DRAG & DROP");
        baslikLabel.setFont(Font.font("Arial", FontWeight.EXTRA_BOLD, 28));
        baslikLabel.setTextFill(Color.WHITE);

        HBox scoreBox = new HBox(16);
        scoreBox.setAlignment(Pos.CENTER);
        scoreBox.setPadding(new Insets(8));

        turLabel = createTag("Tur: 1/5", "#3498db");
        oyuncuSkorLabel = createTag(oyuncu.getOyuncuAdi() + ": 0", "#27ae60");
        bilgisayarSkorLabel = createTag("Bilgisayar: 0", "#e74c3c");
        oyuncuKartSayisiLabel = createTag("Kartlar: 6", "#f39c12");
        bilgisayarKartSayisiLabel = createTag("Bilg. Kartlar: 6", "#9b59b6");
        secimBilgisiLabel = createTag("Seçim: 0/3", "#1abc9c");

        scoreBox.getChildren().addAll(turLabel, oyuncuSkorLabel, bilgisayarSkorLabel,
                oyuncuKartSayisiLabel, bilgisayarKartSayisiLabel, secimBilgisiLabel);

        durumLabel = new Label("Kartları sürükleyip seçilen alana bırak!");
        durumLabel.setFont(Font.font("Arial", FontWeight.BOLD, 14));
        durumLabel.setTextFill(Color.web("#FFD700"));

        topPanel.getChildren().addAll(baslikLabel, scoreBox, durumLabel);
        root.setTop(topPanel);

        // Orta panel - Kartlar
        HBox centerPanel = new HBox(16);
        centerPanel.setPadding(new Insets(12));
        centerPanel.setAlignment(Pos.TOP_CENTER);

        VBox playerSide = createSideBox(oyuncu.getOyuncuAdi(), "Senin Kartların", true);
        oyuncuKartPane = new FlowPane(14, 14);
        oyuncuKartPane.setPadding(new Insets(10));
        oyuncuKartPane.setPrefWrapLength(520);
        oyuncuKartPane.setAlignment(Pos.TOP_LEFT);

        ScrollPane playerScroll = new ScrollPane(oyuncuKartPane);
        playerScroll.setFitToWidth(true);
        playerScroll.setStyle(scrollStyle());
        playerScroll.setPrefViewportHeight(400);
        playerSide.getChildren().add(playerScroll);
        VBox.setVgrow(playerScroll, Priority.ALWAYS);

        VBox computerSide = createSideBox(bilgisayar.getOyuncuAdi(), "Bilgisayar Kartları", false);
        bilgisayarKartPane = new FlowPane(14, 14);
        bilgisayarKartPane.setPadding(new Insets(10));
        bilgisayarKartPane.setPrefWrapLength(520);
        bilgisayarKartPane.setAlignment(Pos.TOP_LEFT);

        ScrollPane computerScroll = new ScrollPane(bilgisayarKartPane);
        computerScroll.setFitToWidth(true);
        computerScroll.setStyle(scrollStyle());
        computerScroll.setPrefViewportHeight(400);
        computerSide.getChildren().add(computerScroll);
        VBox.setVgrow(computerScroll, Priority.ALWAYS);

        centerPanel.getChildren().addAll(playerSide, computerSide);
        HBox.setHgrow(playerSide, Priority.ALWAYS);
        HBox.setHgrow(computerSide, Priority.ALWAYS);
        root.setCenter(centerPanel);

        // Alt panel
        VBox bottomPanel = new VBox(12);
        bottomPanel.setPadding(new Insets(12));

        HBox actionBox = new HBox(12);
        actionBox.setAlignment(Pos.CENTER);

        savasButton = new Button("⚔ SAVAŞI BAŞLAT");
        savasButton.setPrefWidth(200);
        savasButton.setStyle(buttonStyle("#e74c3c", "white"));
        savasButton.setFont(Font.font("Arial", FontWeight.BOLD, 14));
        savasButton.setOnAction(e -> savasiCalistir());

        Button menuButton = new Button("← ANA MENÜ");
        menuButton.setPrefWidth(150);
        menuButton.setStyle(buttonStyle("#95a5a6", "white"));
        menuButton.setFont(Font.font("Arial", FontWeight.BOLD, 12));
        menuButton.setOnAction(e -> showAnaMenu());

        actionBox.getChildren().addAll(savasButton, menuButton);

        VBox selectedBox = new VBox(8);
        selectedBox.setPadding(new Insets(12));
        selectedBox.setStyle(panelStyle());

        Label selectedLabel = new Label("🎯 SÜRÜKLE VE BIRAK - SEÇİLEN KARTLAR");
        selectedLabel.setFont(Font.font("Arial", FontWeight.BOLD, 14));
        selectedLabel.setTextFill(Color.web("#FFD700"));

        secilenKartPane = new VBox(10);
        secilenKartPane.setPadding(new Insets(10));
        secilenKartPane.setMinHeight(80);
        secilenKartPane.setStyle(
                "-fx-background-color: rgba(8, 12, 20, 0.9);" +
                "-fx-border-color: rgba(255, 215, 0, 0.5);" +
                "-fx-border-width: 2;" +
                "-fx-border-radius: 10;" +
                "-fx-border-style: dashed;"
        );
        setupDropZone();

        HBox selectedDisplay = new HBox(12);
        selectedDisplay.setPadding(new Insets(10));
        selectedDisplay.setPrefHeight(90);
        selectedDisplay.setStyle(
                "-fx-background-color: rgba(8, 12, 20, 0.9);" +
                "-fx-border-color: rgba(255, 215, 0, 0.5);" +
                "-fx-border-width: 2;" +
                "-fx-border-radius: 10;"
        );
        selectedDisplay.setAlignment(Pos.CENTER_LEFT);

        selectedBox.getChildren().addAll(selectedLabel, selectedDisplay);
        selectedDisplay.getChildren().add(secilenKartPane);
        HBox.setHgrow(secilenKartPane, Priority.ALWAYS);

        logArea = new TextArea();
        logArea.setEditable(false);
        logArea.setWrapText(true);
        logArea.setPrefRowCount(5);
        logArea.setStyle(
                "-fx-control-inner-background: rgba(8, 12, 20, 0.96);" +
                "-fx-text-fill: #90EE90;" +
                "-fx-font-family: 'Consolas';" +
                "-fx-font-size: 11;" +
                "-fx-background-radius: 10;"
        );

        bottomPanel.getChildren().addAll(actionBox, selectedBox, logArea);
        root.setBottom(bottomPanel);

        Scene scene = new Scene(root, 1200, 800);
        stage.setScene(scene);
    }

    private VBox createSideBox(String title, String subtitle, boolean isPlayer) {
        VBox box = new VBox(8);
        box.setPadding(new Insets(12));
        box.setStyle(panelStyle());

        Label titleLabel = new Label(title);
        titleLabel.setFont(Font.font("Arial", FontWeight.EXTRA_BOLD, 18));
        titleLabel.setTextFill(isPlayer ? Color.web("#61FF9A") : Color.web("#FFD66B"));

        Label subLabel = new Label(subtitle);
        subLabel.setFont(Font.font("Arial", FontWeight.BOLD, 12));
        subLabel.setTextFill(Color.web("#DCE6F1"));

        box.getChildren().addAll(titleLabel, subLabel);
        return box;
    }

    private Label createTag(String text, String color) {
        Label label = new Label(text);
        label.setPadding(new Insets(8, 14, 8, 14));
        label.setTextFill(Color.WHITE);
        label.setFont(Font.font("Arial", FontWeight.BOLD, 12));
        label.setStyle(
                "-fx-background-color: " + color + ";" +
                "-fx-background-radius: 999;" +
                "-fx-border-color: rgba(255,255,255,0.2);" +
                "-fx-border-radius: 999;" +
                "-fx-border-width: 1;"
        );
        return label;
    }

    private void setupDropZone() {
        secilenKartPane.setOnDragOver(event -> {
            if (event.getGestureSource() != secilenKartPane && event.getDragboard().hasString()) {
                event.acceptTransferModes(TransferMode.COPY_OR_MOVE);
            }
            event.consume();
        });

        secilenKartPane.setOnDragDropped(event -> {
            Dragboard db = event.getDragboard();
            if (db.hasString()) {
                try {
                    int kartIndex = Integer.parseInt(db.getString());
                    SavasAraclari kart = oyuncu.getKartListesi().get(kartIndex);

                    if (secilenKartlar.size() < gerekenKartSayisi && !secilenKartlar.contains(kart)) {
                        secilenKartlar.add(kart);
                        updateSecilenDisplay();
                        secimBilgisiLabel.setText("Seçim: " + secilenKartlar.size() + "/" + gerekenKartSayisi);
                        event.setDropCompleted(true);
                    } else if (secilenKartlar.contains(kart)) {
                        secilenKartlar.remove(kart);
                        updateSecilenDisplay();
                        secimBilgisiLabel.setText("Seçim: " + secilenKartlar.size() + "/" + gerekenKartSayisi);
                        event.setDropCompleted(true);
                    }
                } catch (Exception e) {
                    event.setDropCompleted(false);
                }
            }
            event.consume();
        });
    }

    private void updateSecilenDisplay() {
        secilenKartPane.getChildren().clear();
        for (SavasAraclari kart : secilenKartlar) {
            secilenKartPane.getChildren().add(createSmallCard(kart));
        }
        updateButtonStates();
    }

    private StackPane createSmallCard(SavasAraclari kart) {
        StackPane card = new StackPane();
        card.setPrefSize(100, 70);
        card.setStyle(
                "-fx-background-color: " + kartRengi(kart) + ";" +
                "-fx-background-radius: 8;" +
                "-fx-border-color: white;" +
                "-fx-border-width: 2;" +
                "-fx-border-radius: 8;"
        );

        VBox textBox = new VBox(2);
        textBox.setAlignment(Pos.CENTER);

        Label nameLabel = new Label(kartAdi(kart));
        nameLabel.setFont(Font.font("Arial", FontWeight.BOLD, 11));
        nameLabel.setTextFill(Color.WHITE);

        Label sinifarLabel = new Label(kartSinifi(kart));
        sinifarLabel.setFont(Font.font("Arial", 9));
        sinifarLabel.setTextFill(Color.web("#EAF2FF"));

        textBox.getChildren().addAll(nameLabel, sinifarLabel);
        card.getChildren().add(textBox);
        return card;
    }

    private void renderKartlar() {
        oyuncuKartPane.getChildren().clear();
        bilgisayarKartPane.getChildren().clear();

        for (int i = 0; i < oyuncu.getKartListesi().size(); i++) {
            oyuncuKartPane.getChildren().add(createDraggableCard(oyuncu.getKartListesi().get(i), i, true));
        }

        for (SavasAraclari kart : bilgisayar.getKartListesi()) {
            bilgisayarKartPane.getChildren().add(createStaticCard(kart));
        }

        oyuncuKartSayisiLabel.setText("Kartlar: " + oyuncu.getKartListesi().size());
        bilgisayarKartSayisiLabel.setText("Bilg. Kartlar: " + bilgisayar.getKartListesi().size());
        oyuncuSkorLabel.setText(oyuncu.getOyuncuAdi() + ": " + oyuncu.getSkor());
        bilgisayarSkorLabel.setText("Bilgisayar: " + bilgisayar.getSkor());
        turLabel.setText("Tur: " + tur + "/" + MAX_TUR);
    }

    private StackPane createDraggableCard(SavasAraclari kart, int index, boolean isDraggable) {
        StackPane card = new StackPane();
        card.setPrefSize(140, 180);
        card.setStyle(cardStyle(kart));

        if (isDraggable) {
            card.setOnDragDetected(event -> {
                Dragboard db = card.startDragAndDrop(TransferMode.MOVE);
                ClipboardContent content = new ClipboardContent();
                content.putString(String.valueOf(index));
                db.setContent(content);
                event.consume();
            });
        }

        VBox textBox = new VBox(4);
        textBox.setAlignment(Pos.CENTER);

        Label nameLabel = new Label(kartAdi(kart));
        nameLabel.setFont(Font.font("Arial", FontWeight.EXTRA_BOLD, 14));
        nameLabel.setTextFill(Color.WHITE);

        Label klassLabel = new Label(kartSinifi(kart));
        klassLabel.setFont(Font.font("Arial", FontWeight.BOLD, 11));
        klassLabel.setTextFill(Color.web("#EAF2FF"));

        Label statsLabel = new Label("HP: " + kart.getDayaniklilik() + " | ATK: " + kart.getVurus());
        statsLabel.setFont(Font.font("Arial", 10));
        statsLabel.setTextFill(Color.web("#D8E7FF"));

        if (isDraggable) {
            Label dragHint = new Label("↔ Sürükle");
            dragHint.setFont(Font.font("Arial", FontWeight.BOLD, 9));
            dragHint.setTextFill(Color.web("#FFD700"));
            textBox.getChildren().addAll(nameLabel, klassLabel, statsLabel, dragHint);
        } else {
            textBox.getChildren().addAll(nameLabel, klassLabel, statsLabel);
        }

        card.getChildren().add(textBox);
        return card;
    }

    private StackPane createStaticCard(SavasAraclari kart) {
        return createDraggableCard(kart, 0, false);
    }

    private String cardStyle(SavasAraclari kart) {
        return "-fx-background-color: " + kartRengi(kart) + ";" +
               "-fx-background-radius: 12;" +
               "-fx-border-color: rgba(255, 215, 0, 0.6);" +
               "-fx-border-width: 2;" +
               "-fx-border-radius: 12;" +
               "-fx-effect: dropshadow(gaussian, rgba(0, 0, 0, 0.6), 8, 0.5, 0, 2);";
    }

    private String kartRengi(SavasAraclari kart) {
        if (kart instanceof Ucak || kart instanceof Siha) {
            return "linear-gradient(to bottom right, #2E86DE, #1C4E80)";
        }
        if (kart instanceof Obus || kart instanceof KFS) {
            return "linear-gradient(to bottom right, #8E5B3A, #5A3E2B)";
        }
        return "linear-gradient(to bottom right, #17A2B8, #0F5B73)";
    }

    private String kartAdi(SavasAraclari kart) {
        if (kart instanceof Ucak) return "Uçak";
        if (kart instanceof Siha) return "Siha";
        if (kart instanceof Obus) return "Obüs";
        if (kart instanceof KFS) return "KFS";
        if (kart instanceof Firkateyn) return "Firkateyn";
        if (kart instanceof Sida) return "Sida";
        return kart.getClass().getSimpleName();
    }

    private String kartSinifi(SavasAraclari kart) {
        if (kart instanceof Hava) return "🛫 Hava";
        if (kart instanceof Kara) return "🚗 Kara";
        if (kart instanceof Deniz) return "🚢 Deniz";
        return "?";
    }

    private void updateButtonStates() {
        savasButton.setDisable(!(!oyunBitti && secilenKartlar.size() == gerekenKartSayisi && gerekenKartSayisi > 0));
    }

    private void turuHazirla() {
        oyunBitti = false;
        gerekenKartSayisi = gerekliKartSayisi();
        if (gerekenKartSayisi == 0) {
            oyunuBitir();
            return;
        }

        secilenKartlar.clear();
        durumLabel.setText("Tur " + tur + ": " + gerekenKartSayisi + " kartı seçmen gerekiyor!");
        secimBilgisiLabel.setText("Seçim: 0/" + gerekenKartSayisi);
        renderKartlar();
        updateSecilenDisplay();
        logArea.setText("Tur " + tur + " başladı! Kartlarını sürükleyip seçilen alana bırak.\n");
    }

    private int gerekliKartSayisi() {
        if (oyuncu == null || bilgisayar == null) return 0;
        int mevcut = Math.min(oyuncu.getKartListesi().size(), bilgisayar.getKartListesi().size());
        return Math.min(TURNS_PER_ROUND, mevcut);
    }

    private void savasiCalistir() {
        if (oyunBitti || secilenKartlar.size() != gerekenKartSayisi) return;

        List<SavasAraclari> playerSelected = new ArrayList<>(secilenKartlar);
        List<SavasAraclari> computerSelected = bilgisayarSecimleri(gerekenKartSayisi);

        logArea.appendText("\n⚔ TUR " + tur + " SAVAŞI ⚔\n");
        logArea.appendText("Seçim: " + kartListesiYaz(playerSelected) + "\n");
        logArea.appendText("Bilgisayar: " + kartListesiYaz(computerSelected) + "\n\n");

        for (int i = 0; i < playerSelected.size(); i++) {
            SavasAraclari pk = playerSelected.get(i);
            SavasAraclari ck = computerSelected.get(i);

            logArea.appendText(kartAdi(pk) + " ⚔ " + kartAdi(ck) + "\n");
            saldiriHesapla(pk, ck);
            saldiriHesapla(ck, pk);
            logArea.appendText("  → " + kartAdi(pk) + ": " + Math.max(0, pk.getDayaniklilik()) + " HP\n");
            logArea.appendText("  → " + kartAdi(ck) + ": " + Math.max(0, ck.getDayaniklilik()) + " HP\n\n");
        }

        kartlariTemizleVeSkorEkle(playerSelected, oyuncu, bilgisayar);
        kartlariTemizleVeSkorEkle(computerSelected, bilgisayar, oyuncu);

        oyuncuSkorLabel.setText(oyuncu.getOyuncuAdi() + ": " + oyuncu.getSkor());
        bilgisayarSkorLabel.setText("Bilgisayar: " + bilgisayar.getSkor());

        oyunSonrasiKontrol();
        if (oyunBitti) return;

        if (tur < MAX_TUR) {
            tur++;
            oyuncu.getKartListesi().add(donemKartIcinUret(oyuncu));
            bilgisayar.getKartListesi().add(donemKartIcinUret(bilgisayar));
            logArea.appendText("✦ Yeni kartlar eklendi. Sıradaki tur hazırlanıyor...\n");
        }

        turuHazirla();
    }

    private void oyunSonrasiKontrol() {
        if (tur >= MAX_TUR) {
            oyunuBitir();
            return;
        }
        if (oyuncu.getKartListesi().isEmpty() || bilgisayar.getKartListesi().isEmpty()) {
            oyunuBitir();
        }
    }

    private void oyunuBitir() {
        oyunBitti = true;
        savasButton.setDisable(true);
        turLabel.setText("Oyun Bitti!");

        String sonuc;
        if (oyuncu.getSkor() > bilgisayar.getSkor()) {
            sonuc = oyuncu.getOyuncuAdi() + " KAZANDI! 🎉";
        } else if (oyuncu.getSkor() < bilgisayar.getSkor()) {
            sonuc = "Bilgisayar Kazandı! 🤖";
        } else {
            sonuc = "Berabere Bitti! 🤝";
        }

        logArea.appendText("\n" + "=".repeat(50) + "\n");
        logArea.appendText(sonuc + "\n");
        logArea.appendText(oyuncu.getOyuncuAdi() + ": " + oyuncu.getSkor() + "\n");
        logArea.appendText("Bilgisayar: " + bilgisayar.getSkor() + "\n");
        logArea.appendText("=".repeat(50) + "\n");

        bilgiKutusu(Alert.AlertType.INFORMATION, "Oyun Sonu", sonuc + "\n\n" +
                oyuncu.getOyuncuAdi() + ": " + oyuncu.getSkor() + "\n" +
                "Bilgisayar: " + bilgisayar.getSkor());
    }

    private List<SavasAraclari> bilgisayarSecimleri(int adet) {
        List<SavasAraclari> secilebilir = new ArrayList<>(bilgisayar.getKartListesi());
        Collections.shuffle(secilebilir, random);
        return secilebilir.stream().limit(adet).collect(Collectors.toList());
    }

    private void kartlariTemizleVeSkorEkle(List<SavasAraclari> secilenler, Oyuncu sahip, Oyuncu rakip) {
        for (SavasAraclari kart : new ArrayList<>(secilenler)) {
            if (kart.getDayaniklilik() <= 0) {
                sahip.getKartListesi().remove(kart);
                rakip.setSkor(kart.getSeviyePuani());
                logArea.appendText("✗ " + kartAdi(kart) + " elendi! " + rakip.getOyuncuAdi() + " +" + kart.getSeviyePuani() + " puan\n");
            }
        }
    }

    private String kartListesiYaz(List<SavasAraclari> kartlar) {
        return kartlar.isEmpty() ? "(boş)" : kartlar.stream().map(this::kartAdi).collect(Collectors.joining(" + "));
    }

    private void saldiriHesapla(SavasAraclari saldiran, SavasAraclari hedef) {
        int vurusDegeri = saldiran.getVurus();

        if (hedef instanceof Hava && saldiran instanceof Deniz) {
            vurusDegeri += ((Deniz) saldiran).getHavaVurusAvantaji();
        } else if (hedef instanceof Kara && saldiran instanceof Hava) {
            vurusDegeri += ((Hava) saldiran).getKaraVurusAvantaji();
        } else if (hedef instanceof Deniz && saldiran instanceof Kara) {
            vurusDegeri += ((Kara) saldiran).getDenizVurusAvantaji();
        }

        hedef.durumGuncelle(vurusDegeri, 10);
    }

    private SavasAraclari baslangicKartiUret() {
        switch (random.nextInt(3)) {
            case 0: return new Ucak();
            case 1: return new Obus();
            default: return new Firkateyn();
        }
    }

    private SavasAraclari donemKartIcinUret(Oyuncu oyuncu) {
        if (oyuncu.getSkor() < 20) return baslangicKartiUret();
        switch (random.nextInt(6)) {
            case 0: return new Ucak();
            case 1: return new Obus();
            case 2: return new Firkateyn();
            case 3: return new Sida();
            case 4: return new KFS();
            default: return new Siha();
        }
    }

    private void bilgiKutusu(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private String panelStyle() {
        return "-fx-background-color: rgba(20, 28, 38, 0.85);" +
               "-fx-background-radius: 15;" +
               "-fx-border-color: rgba(255,255,255,0.12);" +
               "-fx-border-radius: 15;" +
               "-fx-border-width: 1;";
    }

    private String scrollStyle() {
        return "-fx-background: transparent; -fx-background-color: transparent;";
    }

    private String buttonStyle(String bgColor, String textColor) {
        return "-fx-background-color: " + bgColor + ";" +
               "-fx-text-fill: " + textColor + ";" +
               "-fx-background-radius: 8;" +
               "-fx-padding: 10 20 10 20;" +
               "-fx-border-radius: 8;" +
               "-fx-cursor: hand;";
    }

    private void applyArkaPlan(javafx.scene.layout.Pane pane) {
        if (arkaPlanResmi == null) {
            pane.setStyle("-fx-background-color: linear-gradient(to bottom right, #0B1320, #172B4D);");
            return;
        }

        BackgroundImage bg = new BackgroundImage(
                arkaPlanResmi,
                BackgroundRepeat.NO_REPEAT,
                BackgroundRepeat.NO_REPEAT,
                BackgroundPosition.CENTER,
                new BackgroundSize(100, 100, true, true, true, true)
        );
        pane.setBackground(new Background(bg));
    }

    @SuppressWarnings("unused")
    public static void main(String[] args) {
        launch(args);
    }
}

