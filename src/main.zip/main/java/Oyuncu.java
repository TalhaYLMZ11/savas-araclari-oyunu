import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Random;

public class Oyuncu {
    private int oyuncuID;
    private String oyuncuAdi;
    private int skor;
    private ArrayList<SavasAraclari> kartListesi;
    private HashSet<SavasAraclari> secilenKartlar;
    private ArrayList<Integer> secimler;

    public Oyuncu(int oyuncuID, String oyuncuAdi, int skor) {
        this.oyuncuID = oyuncuID;
        this.oyuncuAdi = oyuncuAdi;
        this.skor = skor;
        this.kartListesi = new ArrayList<>();
        this.secilenKartlar = new HashSet<>();
        this.secimler = new ArrayList<>();
    }

    public void KartEkle(SavasAraclari kart)
    {
        this.kartListesi.add(kart);
    }

    public void setKullaniciSecimleri(List<Integer> secimler) {
    this.secimler = new ArrayList<>(secimler);
    }


    

    public ArrayList<SavasAraclari> kartSec(int sayi)
    {
        ArrayList<SavasAraclari> secilenKartlarListesi = new ArrayList<>();

        if(this.oyuncuID == 1)
        {
            for (Integer index : secimler) {
                SavasAraclari secilenKart = this.kartListesi.get(index);
                secilenKartlarListesi.add(secilenKart);
                this.secilenKartlar.add(secilenKart);
                
            }
        }
        
        else
        {
            ArrayList<SavasAraclari> kullanilabilirKartlar = new ArrayList<>();

            for (SavasAraclari kart : this.kartListesi) {
                if(!this.secilenKartlar.contains(kart))
                {
                    kullanilabilirKartlar.add(kart);
                }
                
            }

            if(kullanilabilirKartlar.size() < sayi)
            {
                this.secilenKartlar.clear();
                kullanilabilirKartlar = new ArrayList<>(this.kartListesi);
            }

            Random random = new Random();

            for (int i = 0; i < sayi && !kullanilabilirKartlar.isEmpty(); i++) {
                int randomIndex = random.nextInt(kullanilabilirKartlar.size());
                SavasAraclari secilenKart = kullanilabilirKartlar.get(randomIndex);

                secilenKartlarListesi.add(secilenKart);
                this.secilenKartlar.add(secilenKart);
                kullanilabilirKartlar.remove(randomIndex);
            }
   
        }

        return secilenKartlarListesi;
    }

    public HashSet<SavasAraclari> getSecilenKartlar()
    {
        return this.secilenKartlar;
    }

    public boolean SecilmisKartlar(SavasAraclari kart)
    {
        return this.secilenKartlar.contains(kart);
    }

    public int getOyuncuID() {
        return this.oyuncuID;
    }

    public String getOyuncuAdi() {
        return this.oyuncuAdi;
    }

    public int getSkor() {
        return this.skor;
    }

    public void setSkor(int skor) {
        this.skor += skor;
    }

    public ArrayList<SavasAraclari> getKartListesi()
    {
        return this.kartListesi;
    }

    public void kartlariTemizle()
    {
        this.kartListesi.clear();
    }

    public void kartlariSifirla()
    {
        this.kartListesi = new ArrayList<>();
    }

    public int getToplamSeviye()
    {
        int toplamSeviye = 0;
        for (SavasAraclari kart : this.kartListesi) {
            toplamSeviye += kart.getSeviyePuani();
            
        }
        return toplamSeviye;
    }

    public int toplamDayaniklilik()
    {
        int toplamDayaniklilik = 0;
        for (SavasAraclari kart : this.kartListesi) {
            toplamDayaniklilik += kart.getDayaniklilik();
            
        }

        return toplamDayaniklilik;
    }

}
